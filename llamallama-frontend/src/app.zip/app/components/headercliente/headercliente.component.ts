import { Component, OnInit } from '@angular/core';
import { Producto } from 'src/app/models/producto.model';
import { ExplorerService } from 'src/app/services/explorer.service';

@Component({
  selector: 'app-headercliente',
  templateUrl: './headercliente.component.html',
  styleUrls: ['./headercliente.component.css']
})
export class HeaderclienteComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
 

    }

}
