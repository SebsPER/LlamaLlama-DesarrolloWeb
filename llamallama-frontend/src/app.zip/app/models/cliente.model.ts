export class Cliente{
    id: number;
    name: string;
    dni: number;
    direccion: string;
    telefono: number;
    apellido_paterno: string;
    apellido_matenro: string;
    password: string;
    compra: any[];
}