export class Categoria{
    codigo: number;
    nombre: string;
    descripcion: string;
    productos: any[];
}