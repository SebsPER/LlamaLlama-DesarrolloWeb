export class Compra{
    id: number;
    fecha: any;
    direccion: string;
    ciudad_envio: string;
    distrito_envio: string;
    monto_total: number;
    tipo_pagoid: number;
    compraid: any[]
    clienteid: number;
}