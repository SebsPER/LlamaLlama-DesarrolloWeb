export class Tienda{
    id: number;
    nombre:string;
    ruc: number;
    razon_social: string;
    direccion: string;
    nombre_encargado: string;
    password: string;
    products: any[];
}