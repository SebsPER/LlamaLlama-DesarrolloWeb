export class Compra_producto{
    id: number;
    cant_productos: number;
    date: any;
    compraid: number;
    productoid: number;
}