export class Tipo_pago{
    codigo: number;
    nombre: string;
    descripcion: string;
    descuento: number;
    compras: any[];
}