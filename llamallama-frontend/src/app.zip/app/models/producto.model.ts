export class Producto{
    id: number;
    nombre: string;
    precio: number;
    Tienda_producto: any[];
    Compra_producto: any[];
    categoriaid: number;
}