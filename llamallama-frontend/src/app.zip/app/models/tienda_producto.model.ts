
export class Tienda_producto{
    id: number;
    cant_tiendas: number;
    date: any;
    productoid: number;
    tiendaid: number;
}